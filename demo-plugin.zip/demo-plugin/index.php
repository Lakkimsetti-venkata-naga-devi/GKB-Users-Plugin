<?php 
// silence is golden