<?php

/** 
 * Trigger this file on plugin uninstall
 * 
 * @package demo_plugin
 */
if(! defined('WP_UNINSTALL_PLUGIN')){
    exit;
}

