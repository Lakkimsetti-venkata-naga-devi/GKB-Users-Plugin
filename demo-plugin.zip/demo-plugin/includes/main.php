<?php 
if(is_admin()){
echo "<div class='container'>
    <h3>Hello, Welcome to GKB Users Plugin</h3>
    <h6>Thank you for installing the Demo plugin. Here is the user manual to use of plugin. Please check the instructions. How to use the Plugin.</p>
    <p>1. Please create the user by click on create user menu option and fill the details.</p>
    <p>2. If you have data in CSV, don't worry you can easily import and add the users by clicking on import data Menu option.</p>
    <p>3. Please check the list the users that already have.</p>
</div>";
}
?>